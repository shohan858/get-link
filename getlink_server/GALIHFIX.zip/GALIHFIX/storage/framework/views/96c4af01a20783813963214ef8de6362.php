<?php $__env->startSection('konten'); ?>
    <main>
        <div class="content">
            <div class="lang-content hidden">
                <div class="langganan-topBagi">
                    <div class="langganan-bagi">
                        <div class="langganan-teks">
                            <p class="langganan-h1">Paket Microsite</p>
                            <p class="langganan-p">
                                Lorem ipsum is placeholder text commonly used in the graphic,
                                print, and publishing industries for previewing layouts and
                                visual mockups. br
                            </p>
                        </div>
                        <div class="bungkus-Ccard">
                            <div class="lalang">
                                <div class="langganan-card">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="langganan-p1">
                                            <div class="langganan-des">
                                                <img class="card_arrow" src="<?php echo e(asset('assets/img/Vector 10.png')); ?>"
                                                    alt="">
                                                <p class="p1-h1"><?php echo e($item->name); ?></p>
                                                <p class="p1-r">Rp. <?php echo e($item->harga); ?></p>
                                                <p class="p1-des">
                                                    Dalam <?php echo e($item->name); ?> anda akan mendapatkan jumlah slot
                                                    <?php echo e($item->slot); ?>

                                                    dengan harga terjangkau
                                                </p>
                                                <div class="langganan-bottom">
                                                    <a target="_blank" class="p1-lang" href="tambah_slot_microsite/<?php echo e($item->id); ?>">
                                                        Langganan Sekarang
                                                    </a>
                                                </div>
                                                <div id="paket-container"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layout.Dashboard_User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Dashboard_User.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Downloads\okehhgetnk\GALIHFIX\resources\views/Dashboard_User/langganan.blade.php ENDPATH**/ ?>