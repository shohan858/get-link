<?php $__env->startSection('konten'); ?>
    <main>
        <div class="content">
            <div class="ddaash-content hidden">
                <div class="anim dashboard-content-isi">
                    <div class="dashboard-teks">
                        <p class="dashboard-h1">SELAMAT DATANG,</p>
                        <p class="dashboard-nama">
                            <?php echo e(Auth::user()->name); ?>

                            
                            
                        </p>

                        
                    </div>

                    <div class="dashboard-bawah">

                        <div class="dashboard-card">
                            <div class="dashboard-micro">
                                <img src="assets/img/Vector (15).png" alt=""  class="img_dc"/>
                                <p class="pengunjung-1">Microsite dibuat</p>
                                <p class="pengunjung-p">
                                    <?php echo e($count_microsite); ?>/<?php echo e($limit_microsite); ?> Microsite</p>
                            </div>
                            <div class="dashboard-sl">
                                <img src="assets/img/Vector.png" alt="" class="img_dc">
                                <p class="pengunjung-1">Short Link</p>
                                <p class="pengunjung-p">0 shortLink</p>
                            </div>
                        </div>
                        <div class="chartDash">

                            <div class="bung_chart">
                                <canvas id="myChart"></canvas>
                            </div>
                            <div class="botChart">
                                <div class="tahunth">
                                    <select class="sy" id="year" onchange="updateChart()">
                                        <option class="as" value="<?php echo e(date('Y') - 2); ?>"><?php echo e(date('Y') - 2); ?></option>
                                        <option value="<?php echo e(date('Y') - 1); ?>"><?php echo e(date('Y') - 1); ?></option>
                                        <option value="<?php echo e(date('Y')); ?>" selected><?php echo e(date('Y')); ?></option>
                                    </select>
                                    <label class="th" for="year">Tahun</label>
                                </div>

                                <div class="tvchart">
                                    <p class="tovi" id="totalVisitors">0</p>
                                    <p class="tovi">Total Visitor</p>
                                </div>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layout.Dashboard_User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </main>
    <div id="sudah" class="selesai" style="display: none;">
        <!-- Modal content -->
        <div class="selesai-jadi">
            <span class="selesai-close">&times;</span>
            <img src="img/pinkphone.png" alt="" class="hppink" />
            <p class="selesai-tulisan2">Selamat!! Microsite anda sudah jadi</p>
            <button class="selesai-button">Oke</button>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('myChart').getContext('2d');
        let tahun_ini = <?php echo json_encode($data_tahun_ini); ?>;
        let data_tahun_ini = JSON.parse("[" + tahun_ini + "]");

        let tahun_kemarin = <?php echo json_encode($data_tahun_kemarin); ?>;
        let data_tahun_kemarin = JSON.parse("[" + tahun_kemarin + "]");

        let tahun_kemarin2 = <?php echo json_encode($data_tahun_kemarin2); ?>;
        let data_tahun_kemarin2 = JSON.parse("[" + tahun_kemarin2 + "]");

        const data = {
            labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober',
                'November', 'Desember'
            ],
            datasets: [{
                label: 'Total pengunjung',
                data: data_tahun_ini,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        };
        const options = {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        };
        const chart = new Chart(ctx, {
            // type: 'line', // Lek pengin garis
            type: 'bar',    // Lek pengin block
            data: data,
            options: options
        });

        function updateChart() {
            const year = document.getElementById('year').value;
            let totalVisitors = 0;
            if (year === 'all') {
                totalVisitors = allData.flat().reduce((a, b) => a + b, 0);
                chart.data.datasets[0].data = allData.reduce((acc, val) => acc.map((v, i) => v + val[i]));
            } else if (year === '<?php echo e(date('Y') - 2); ?>') {
                totalVisitors = data_tahun_kemarin2.reduce((a, b) => a + b, 0);
                chart.data.datasets[0].data = data_tahun_kemarin2;
            } else if (year === '<?php echo e(date('Y') - 1); ?>') {
                totalVisitors = data_tahun_kemarin.reduce((a, b) => a + b, 0);
                chart.data.datasets[0].data = data_tahun_kemarin;
            } else if (year === '<?php echo e(date('Y')); ?>') {
                totalVisitors = data_tahun_ini.reduce((a, b) => a + b, 0);
                chart.data.datasets[0].data = data_tahun_ini;
            }
            document.getElementById('totalVisitors').innerHTML = `${totalVisitors}`;
            chart.update();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Dashboard_user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Downloads\okehhgetnk\GALIHFIX\resources\views/Dashboard_User/dashboard.blade.php ENDPATH**/ ?>