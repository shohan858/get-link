<footer>
    <div class="footer">
        <p>&copy; 2023 Nama Perusahaan. Hak Cipta Dilindungi.</p>
    </div>
</footer>
<?php /**PATH C:\Users\galih agung raharjo\Documents\github\final_getlink\PROJEK_FINAL\Getlink_New_GALIH_terbarunya_baru\resources\views/layout/Dashboard_User/footer.blade.php ENDPATH**/ ?>