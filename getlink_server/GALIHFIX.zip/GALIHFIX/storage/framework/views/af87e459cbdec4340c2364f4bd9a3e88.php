<nav>
    <div class="navbar navAni">
        <div class="navbar-kiri">
            
            <button class="button-side">
                
                <span class="navbar-menu">
                    <i id="bars" style="color: #fff" class="fa-solid fa-bars hahaha"></i>
                </span>
            </button>
            <img class="navbar-img" src="<?php echo e(asset('assets/img/logo-text2 1.png')); ?>" alt="" />
        </div>
        <div class="navKanan">
            

            
            <a href="/langganan" class="navbar-upgrade">
                <i class="fa-solid fa-file"></i>
                Paket microsite
            </a>

            <div class="profil_div">
                <button id="prov_btn" class="profil_nav">
                    <?php if(Auth::user()->img == null): ?>
                        <img src="<?php echo e(asset('assets/img/Ellipse 63.png')); ?>" alt="" class="img_nav">
                    <?php else: ?>
                        <img src="<?php echo e(asset('gambar') . "/" .Auth::user()->img); ?>" alt="" class="img_nav">
                    <?php endif; ?>
                    <p id="teks" class="nama_nav"><?php echo e(Auth::user()->name); ?></p>
                    <i id="drwon" class="fa-solid fa-chevron-up nama_nav"></i>
                </button>
                <div id="prof_drop" class="prof_dropdown">
                    <a href="/profile/edit/<?php echo e(Auth::user()->id); ?>" class="drop-is"
                        style="border-bottom: 1px solid #524799; border-radius: 10px 10px 0 0;">
                        <i class="fa-regular fa-user" style="margin-right: 10px"></i>
                        Profile
                    </a>
                    <a href="<?php echo e(url('logout')); ?>" class="drop-is" style="border-radius:0 0 10px 10px;">
                        <i class="fa-solid fa-arrow-right-from-bracket" style="margin-right: 10px"></i>
                        Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>

<script>
    const btnProf = document.getElementById("prov_btn");
    const drown = document.getElementById("drwon");
    const dropProf = document.getElementById("prof_drop")

    btnProf.addEventListener("click", function() {
        // btnProf.classList.toggle("profte");
        dropProf.classList.toggle("prof_tampil");
        if (drown.classList.contains("fa-chevron-down")) {
            drown.classList.remove("fa-chevron-down");
            drown.classList.add("fa-chevron-up");
        } else {
            drown.classList.remove("fa-chevron-up");
            drown.classList.add("fa-chevron-down");
        }
    })

    const teks = document.getElementById("teks");
    if (teks.innerText.length > 8) {
        teks.innerText = teks.innerText.slice(0, 8);
    }
</script>
<?php /**PATH C:\Users\galih agung raharjo\Documents\github\final_getlink\PROJEK_FINAL\Getlink_New_GALIH_terbarunya_baru\resources\views/layout/Dashboard_user/_nav.blade.php ENDPATH**/ ?>