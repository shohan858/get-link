<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style_admin.css')); ?>">
</head>
<body>
    <?php if($background->type_background == 'color'): ?>
        <div class="bungkus" style='background: <?php echo e($background->background); ?>'>
    <?php else: ?>
        <div class="bungkus" style="background-image: url('<?php echo e(asset('microsite/background/'.$background->background)); ?>')">
    <?php endif; ?>
            <?php $non_bungkus = ''; ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // mengganti string "src=" pada folder "microsite/konten/"
                    $html = str_replace('src="microsite/konten', 'src="' . asset('microsite/konten/'), $d['code']);
                    // mengganti string "src=" pada folder "microsite/medsos/"
                    $html = str_replace('src="microsite/medsos', 'src="' . asset('microsite/medsos/'), $html);
                    $non_bungkus .= $html;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo $non_bungkus; ?>

        </div>
</body>
</html><?php /**PATH E:\Downloads\okehhgetnk\GALIHFIX\resources\views/admin/template/preview.blade.php ENDPATH**/ ?>