<footer>
    <div class="footer">
        <p>&copy; 2023 GetLink. Hak Cipta Dilindungi.</p>
    </div>
</footer>
<?php /**PATH E:\Downloads\okehhgetnk\GALIHFIX\resources\views/layout/Dashboard_User/footer.blade.php ENDPATH**/ ?>