<footer>
    <div class="footer">
        <p>&copy; 2023 GetLink. Hak Cipta Dilindungi.</p>
    </div>
</footer>
