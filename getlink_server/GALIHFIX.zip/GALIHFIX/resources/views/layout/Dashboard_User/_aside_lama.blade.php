<aside class="aniLeft">
    <div class="aside">
      <a href="/dashboard_user">
        <button class="aside-button">Dashboard</button>
      </a>
      <!-- <a href="index.html"> -->
      <div class="aside-drop">
        <button class="aside-button">
          Microsite
          <svg
            class="svg-micro"
            width="9"
            height="14"
            viewBox="0 0 9 14"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M1.94219 12.9998L7.37109 7.34309L1.94219 1.68643"
              stroke="#6B75E6"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </button>
        <div class="dropdowncontent">
          <a class="drop-top" href="/regular">Microsite regular</a>
          <a class="drop-bottom" href="/langganan">Microsite langganan</a>
        </div>
      </div>
      <!-- </a> -->
    </div>
  </aside>