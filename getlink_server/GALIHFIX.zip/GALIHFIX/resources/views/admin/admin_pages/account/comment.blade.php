@extends("admin.layout.base")

@section("admin_konten")

<div class="adDash">

</div>

@endsection
